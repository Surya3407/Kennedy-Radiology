package com.example.UntitledTestSuite;

import java.util.regex.Pattern;
import java.util.concurrent.TimeUnit;
import org.testng.annotations.*;
import static org.testng.Assert.*;
import org.openqa.selenium.*;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.support.ui.Select;
import java.io.File;
import org.apache.commons.io.FileUtils;

public class UntitledTestCase {
  private WebDriver driver;
  private String baseUrl;
  private boolean acceptNextAlert = true;
  private StringBuffer verificationErrors = new StringBuffer();
  private JavascriptExecutor js;

  @BeforeClass(alwaysRun = true)
  public void setUp() throws Exception {
    System.setProperty("webdriver.chrome.driver", "java");
    driver = new ChromeDriver();
    baseUrl = "https://www.google.com/";
    driver.manage().timeouts().implicitlyWait(Duration.ofSeconds(30));
    js = (JavascriptExecutor) driver;
  }

  @Test
  public void testUntitledTestCase() throws Exception {
    driver.get("https://katalon.com/verify-email");
    driver.findElement(By.xpath("//*/text()[normalize-space(.)='']/parent::*")).click();
    driver.findElement(By.xpath("(.//*[normalize-space(text()) and normalize-space(.)='Copyright © 2022 Katalon, Inc. All rights reserved.'])[1]/following::div[4]")).click();
    driver.get("https://www.kennedyradiology.com/");
    driver.findElement(By.xpath("(.//*[normalize-space(text()) and normalize-space(.)='There are no items in the Cart. Would you like to add now?'])[1]/following::span[1]")).click();
    driver.findElement(By.linkText("Logout")).click();
    driver.findElement(By.xpath("//div[2]/button/span/i")).click();
    driver.findElement(By.linkText("Login")).click();
    driver.findElement(By.id("username")).click();
    driver.findElement(By.id("username")).clear();
    driver.findElement(By.id("username")).sendKeys("surya.p.pixel@gmail.com");
    driver.findElement(By.id("password")).click();
    driver.findElement(By.id("password")).clear();
    driver.findElement(By.id("password")).sendKeys("Surya@07");
    driver.findElement(By.xpath("//div[@id='show_hide_password']/div/a/i")).click();
    driver.findElement(By.xpath("//div[@id='show_hide_password']/div/a/i")).click();
    driver.findElement(By.xpath("//form[@id='login']/div/div[3]/div/button[2]")).click();
    driver.findElement(By.linkText("My Address")).click();
    driver.findElement(By.linkText("My Order")).click();
    driver.findElement(By.linkText("Products")).click();
    driver.findElement(By.xpath("//div[@id='divproductlists']/div/div[4]/div/button")).click();
    driver.findElement(By.xpath("//form[@id='frmcustomattr']/div[5]/div/div[2]/div[2]/label")).click();
    driver.findElement(By.xpath("//form[@id='frmcustomattr']/div[5]/div/div[2]/div/label")).click();
    driver.findElement(By.xpath("//span[2]/button/span")).click();
    driver.findElement(By.xpath("//span[2]/button/span")).click();
    driver.findElement(By.xpath("//span[2]/button/span")).click();
    driver.findElement(By.xpath("//span[2]/button/span")).click();
    driver.findElement(By.xpath("(.//*[normalize-space(text()) and normalize-space(.)='Add to cart'])[1]/following::button[1]")).click();
    driver.findElement(By.xpath("//div[@id='collapseOne']/div/div[3]/button")).click();
    driver.findElement(By.xpath("//div[@id='collapseTwo']/div/div[2]/div/button[2]")).click();
    driver.findElement(By.xpath("//div[@id='collapseThree']/div/div/div[2]/button[2]")).click();
    driver.findElement(By.xpath("//button[@type='submit']")).click();
    driver.get("https://www.sandbox.paypal.com/cgi-bin/webscr?cmd=_express-checkout&token=EC-6JW91416T0687212S");
    driver.findElement(By.id("payment-submit-btn")).click();
    driver.get("https://www.kennedyradiology.com/checkout/successPayment?paymentId=PAYID-MNQMXBQ1WJ38165344134544&token=EC-6JW91416T0687212S&PayerID=Y32ZVWPLY4RGG");
  }

  @AfterClass(alwaysRun = true)
  public void tearDown() throws Exception {
    driver.quit();
    String verificationErrorString = verificationErrors.toString();
    if (!"".equals(verificationErrorString)) {
      fail(verificationErrorString);
    }
  }

  private boolean isElementPresent(By by) {
    try {
      driver.findElement(by);
      return true;
    } catch (NoSuchElementException e) {
      return false;
    }
  }

  private boolean isAlertPresent() {
    try {
      driver.switchTo().alert();
      return true;
    } catch (NoAlertPresentException e) {
      return false;
    }
  }

  private String closeAlertAndGetItsText() {
    try {
      Alert alert = driver.switchTo().alert();
      String alertText = alert.getText();
      if (acceptNextAlert) {
        alert.accept();
      } else {
        alert.dismiss();
      }
      return alertText;
    } finally {
      acceptNextAlert = true;
    }
  }
}
